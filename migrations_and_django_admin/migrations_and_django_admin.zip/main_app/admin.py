from main_app.models import Product
from django.contrib import admin

admin.site.register(Product)